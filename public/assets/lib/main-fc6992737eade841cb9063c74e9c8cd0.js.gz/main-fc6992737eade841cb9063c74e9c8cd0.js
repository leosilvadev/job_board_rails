(function() {
  (function() {})();

}).call(this);
